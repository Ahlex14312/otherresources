<!DOCTYPE html>
<html>
<head>
    <title>Jquery Ajax</title>
    <link rel="icon" type="image/icon" href="../Resources/Pictures/jquery ajax logo.png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="index.js"></script>
    <link rel="stylesheet" href="style.css">

</head>
<body>
 
<div>
    <div class="xxpadding">
        <h1 class="text-center zoom">Comments Information</h1>
        <hr style="width:30%; margin-left:35%;  margin-bottom: 80px; height:5px; background:green">
    </div>
   
    <button class="button">Display Comments Information</button>
    <br>
    <br> 
    <input id="myInput" type="text" placeholder="Search comment information...">
    <br>
    <br>
    <table>
        <thead>
            <tr>
                <th>Full Name</th>
                <th>Age</th>
                <th>Address</th>
                <th>Course</th>
                <th>Message</th>
            </tr>
        </thead>
        <tbody id="myTable">

        </tbody>
    </table>
    <br>

    <div id="div1"></div>
    <br><br>

</body>

</html>
