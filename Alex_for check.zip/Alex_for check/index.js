



$(document).ready(function () {

    $("button").click(function () {
        
        $.ajax({
            url: "https://testapi.io/api/Ahlex/sample",
            dataType: "json",
            success: function (data) {
               console.log(data);
               for (var e of data) {
                  $("#myTable").append("<tr><td>" + e.fname + "</td><td>" + e.age + "</td><td>" + e.address+ "</td><td>" + e.course+ "</td><td>" +e.message+ "</td></tr>")
                 
                }
            }
        });
       $("button").attr ("disabled","disabled");        
    });

    $("#myInput").on("keyup", function () {
        var value = $(this).val().toLowerCase();
        $("#myTable tr").filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
    
 });