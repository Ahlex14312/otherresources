<?php
 function displayDateTime($oldDate){
         $newdate = strtotime($oldDate);
         echo strtoupper(date('Y-m-d h:i:s a', $newdate));
     }
?>