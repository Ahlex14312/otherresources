<?php
include_once "function.php";
 $myDate ='September 14, 2029, 10:35:00 AM';
displayDateTime($myDate);
?>