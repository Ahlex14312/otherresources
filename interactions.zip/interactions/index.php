<?php
$tasks = $_POST['tasks'];
if ($tasks != ""){
    $datahandler = fopen("tasks.txt","a+");
    fwrite($datahandler, $tasks."\n");
}
$tasksarray = [];
$datahandler = fopen("tasks.txt","a+");
$i=1;
while(! feof($datahandler)){
    $line =  fgets($datahandler);
    array_push($tasksarray, '  '.$i.'. '.$line);
$i++;
}
fclose($datahandler);
$tasksarray=implode(' ',$tasksarray);
echo json_encode(array("tasks" => $tasksarray));

?>
