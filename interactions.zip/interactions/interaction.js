$(function(){

    $.get("tasks.txt", function (data) {
        var listofTasks = '<ol type = "1">';
        var myData = data.split("\n");
        for (i = 0; i < myData.length; i++) {
            if (myData[i] != null || myData[i] != undefined)
            listofTasks += '<li>' + myData[i] + '</li>';
        }
        listofTasks += '</ol>';
        $("#taskAppend").html(listofTasks);
    })
    $('#taskforms').submit(function (e) {
        e.preventDefault();
        $.ajax({
            type: 'POST',
            url: 'index.php',
            data: $(this).serialize(),
            success: function (response) {
                // alert("Done!!!"); 
                console.log(response);
                var jsonData=JSON.parse(response);	
       
                    $("#taskAppend").html('<p>'+jsonData['tasks']+'</p>');
                
            
            }
        })
    })

})