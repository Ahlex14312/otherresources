<?php
$tasks = $_POST['tasks'];
if ($tasks != " "){
    $datahandler = fopen("tasks.txt","a+");
    fwrite($datahandler, $tasks."\n");
}
$tasksarray = ["$tasks"];
$datahandler = fopen("tasks.txt","a+");
while(! feof($datahandler)){
    $line =  fgets($datahandler);
    array_push($tasksarray, $line);
}
fclose($datahandler);
echo json_encode(array("tasks" => $tasksarray));
?>
